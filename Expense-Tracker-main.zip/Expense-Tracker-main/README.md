# Expense Tracker React app

## Key features of the Expense Tracker website include:
- 📝 Easy expense entry and categorization
- 📊 Interactive charts and graphs for visualizing expenses
- 💾 Data persistence using local storage

<br>

## 𝐆𝐢𝐭𝐡𝐮𝐛 𝐋𝐢𝐧𝐤: https://github.com/keshavop/expense-tracker
## 𝐋𝐢𝐯𝐞 𝐋𝐢𝐧𝐤: https://expensetrackerkeshavop.vercel.app
